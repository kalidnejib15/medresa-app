# Abubeker Medresa Website Assets Package

This zip package contains the official visual assets and constants for the **Abubeker Medresa 2019 Student Registration Web Application**.

## File Directory & Usage

1. **`logo.png` / `logo.jpg`**:
   - Official Abubeker Medresa circular seal/logo.
   - Recommended for top navigation bar (`<nav>`), header branding, and form hero section.

2. **`logo_hd.jpg`**:
   - Ultra-high-resolution version of the Medresa logo.
   - Recommended for print layouts, registration receipts, and large display headers.

3. **`favicon.png`**:
   - Browser tab icon (drop into `public/favicon.ico` or `app/favicon.ico`).

4. **`medresa_bg.jpg`**:
   - Authentic Medresa atmosphere background image with gentle Islamic architectural elements.
   - Ideal for subtle watermark backgrounds, hero banners, or login screens with an opacity overlay (`bg-cover bg-center opacity-10` or dark overlay).

5. **`logoBase64.ts` & `logo_base64.txt`**:
   - Direct base64 Data URI string of the official logo (`data:image/jpeg;base64,...`).
   - Essential for generating instant **printable registration cards, PDF admission slips, or receipts** in browser canvas/print windows without any CORS, image load delays, or broken image link issues.

## Official Brand Colors

- **Primary Emerald Green**: `#065f46` (Deep Islamic green)
- **Primary Dark**: `#064e3b` (Headers and primary buttons)
- **Accent Gold / Amber**: `#d97706` / `#f59e0b` (Badges, highlights, active states)
- **Background Slate**: `#0f172a` (Dark mode) / `#f8fafc` (Light card background)
- **Border / Divider**: `#e2e8f0`
- **Text Color**: `#0f172a` (Headings) / `#475569` (Body text)
