import { create } from 'zustand';
import * as Crypto from 'expo-crypto';
import { getDatabase, queueSync } from '../lib/database';

export type NuraniyahRating = 'excellent' | 'good' | 'needs_work';

export interface NuraniyahAssessment {
  id: string;
  student_id: string;
  date: string;
  category: string; // 'Qirat', 'Azkar', 'Behaviour'
  rating: NuraniyahRating;
  ustaz_id: string;
  notes?: string;
}

const CATEGORIES = ['Qirat', 'Azkar', 'Behaviour'];

const RATING_CONFIG: Record<NuraniyahRating, { label_am: string; label_en: string; emoji: string; color: string; bg: string }> = {
  excellent:   { label_am: 'በጣም ጥሩ',  label_en: 'Excellent',   emoji: '🌟', color: '#059669', bg: '#f0fdf4' },
  good:        { label_am: 'ጥሩ',       label_en: 'Good',        emoji: '✅', color: '#2563eb', bg: '#eff6ff' },
  needs_work:  { label_am: 'ልምምድ ያስፈልጋል', label_en: 'Needs Work', emoji: '📖', color: '#d97706', bg: '#fffbeb' },
};

interface NuraniyahState {
  categories: string[];
  ratingConfig: typeof RATING_CONFIG;
  getAssessments: (studentId: string, date: string) => Promise<NuraniyahAssessment[]>;
  saveAssessment: (studentId: string, date: string, category: string, rating: NuraniyahRating, ustazId: string, notes?: string) => Promise<void>;
  getDailyClassAssessments: (date: string, levelId?: string) => Promise<any[]>;
}

export const useNuraniyahStore = create<NuraniyahState>(() => ({
  categories: CATEGORIES,
  ratingConfig: RATING_CONFIG,

  getAssessments: async (studentId, date) => {
    const db = await getDatabase();
    return db.getAllAsync<NuraniyahAssessment>(
      'SELECT * FROM nuraniyah_assessments WHERE student_id = ? AND date = ? ORDER BY category ASC',
      [studentId, date]
    );
  },

  saveAssessment: async (studentId, date, category, rating, ustazId, notes = '') => {
    const db = await getDatabase();
    const id = `nur_${studentId}_${date}_${category}`;
    const existing = await db.getFirstAsync<{ id: string }>(
      'SELECT id FROM nuraniyah_assessments WHERE id = ?',
      [id]
    );
    const action = existing ? 'update' : 'insert';

    await db.runAsync(
      `INSERT OR REPLACE INTO nuraniyah_assessments (id, student_id, date, category, rating, ustaz_id, notes)
       VALUES (?,?,?,?,?,?,?)`,
      [id, studentId, date, category, rating, ustazId, notes]
    );
    await queueSync('nuraniyah_assessments', id, action);

    const { triggerBackgroundSync } = await import('../lib/sync');
    triggerBackgroundSync(true); // 🚀 INSTANT DISPATCH
  },

  getDailyClassAssessments: async (date, levelId) => {
    const db = await getDatabase();
    let query = `
      SELECT na.*, s.name_am, s.name_en, s.level_id
      FROM nuraniyah_assessments na
      JOIN students s ON na.student_id = s.id
      WHERE na.date = ?
    `;
    const params: any[] = [date];
    if (levelId) {
      query += ' AND s.level_id = ?';
      params.push(levelId);
    }
    return db.getAllAsync(query, params);
  },
}));
