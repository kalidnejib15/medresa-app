import { create } from 'zustand';
import { getDatabase, queueSync } from '../lib/database';
import * as Crypto from 'expo-crypto';
import { triggerBackgroundSync } from '../lib/sync';

export interface ProgressRecord {
  id: string;
  student_id: string;
  ustaz_id: string;
  date: string;
  page_number: string;   // e.g. "Page 12" or "الفاتحة"
  ayah_from: string;     // starting ayah/line
  ayah_to: string;       // ending ayah/line
  lesson_details: string; // extra/additional notes
  rating: number;         // 1–5 stars
  ustaz_notes: string;
  level_id: string;
}

interface ProgressState {
  saveProgress: (record: Omit<ProgressRecord, 'id'>) => Promise<boolean>;
  getDailyProgress: (date: string, level_id?: string, ustaz_id?: string) => Promise<ProgressRecord[]>;
}

export const useProgressStore = create<ProgressState>(() => ({
  saveProgress: async (record) => {
    try {
      const db = await getDatabase();

      // 🛡️ OWNERSHIP LOCK: Separate records by Ustaz
      const existing = await db.getFirstAsync<{ id: string }>(
        'SELECT id FROM student_progress WHERE student_id = ? AND date = ? AND level_id = ? AND ustaz_id = ?',
        [record.student_id, record.date, record.level_id, record.ustaz_id]
      );

      const id = existing?.id ?? Crypto.randomUUID();
      const action = existing ? 'update' : 'insert';

      // UPSERT — update if exists, insert if not
      await db.runAsync(
        `INSERT INTO student_progress
           (id, student_id, ustaz_id, date, page_number, ayah_from, ayah_to, lesson_details, rating, ustaz_notes, level_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           ustaz_id       = excluded.ustaz_id,
           page_number    = excluded.page_number,
           ayah_from      = excluded.ayah_from,
           ayah_to        = excluded.ayah_to,
           lesson_details = excluded.lesson_details,
           rating         = excluded.rating,
           ustaz_notes    = excluded.ustaz_notes`,
        [
          id,
          record.student_id,
          record.ustaz_id,
          record.date,
          record.page_number  ?? '',
          record.ayah_from    ?? '',
          record.ayah_to      ?? '',
          record.lesson_details ?? '',
          record.rating,
          record.ustaz_notes  ?? '',
          record.level_id,
        ]
      );

      // Queue for cloud sync
      await queueSync('student_progress', id, action);

      triggerBackgroundSync(true); // 🚀 INSTANT DISPATCH
      return true;
    } catch (e) {
      console.error('Error saving progress:', e);
      return false;
    }
  },

  getDailyProgress: async (date, level_id, ustaz_id) => {
    try {
      const db = await getDatabase();
      const user = (await import('./useAuthStore')).useAuthStore.getState().user;
      if (!user) return [];

      // 🛡️ MONITORING OVERRIDE: Admins can view ANY teacher's progress
      const targetUstazId = ustaz_id || user.id;

      let query = 'SELECT * FROM student_progress WHERE date = ? AND ustaz_id = ?';
      let params: any[] = [date, targetUstazId];
      
      if (level_id) {
        query += ' AND level_id = ?';
        params.push(level_id);
      }

      return db.getAllAsync<ProgressRecord>(query, params);
    } catch (e) {
      console.error('Error fetching progress:', e);
      return [];
    }
  },
}));
