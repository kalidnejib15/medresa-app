import { Stack, Redirect, useSegments, usePathname } from 'expo-router';
import { useAuthStore } from '../../src/store/useAuthStore';
import React from 'react';

export default function AdminLayout() {
  const user = useAuthStore(s => s.user);
  const pathname = usePathname();

  // 🛡️ Unauthorized Path Protection: Force redirect if non-admin attempts to enter
  // EXCEPTION: Ustazs are allowed to view the Student Detail dossier page (any /students/<id> path)
  const isStudentDetail = pathname.includes('/students/') && !pathname.endsWith('/add');
  const isUstaz = user?.role === 'ustaz';
  const isFinance = user?.role === 'finance';
  
  if (!user || (user.role !== 'admin' && !(isUstaz && isStudentDetail) && !(isFinance && isStudentDetail))) {
    return <Redirect href="/(tabs)/dashboard" />;
  }


  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="students/add" />
      <Stack.Screen name="students/[id]" />
      <Stack.Screen name="teachers" />
      <Stack.Screen name="manage-subjects" />
    </Stack>
  );
}
